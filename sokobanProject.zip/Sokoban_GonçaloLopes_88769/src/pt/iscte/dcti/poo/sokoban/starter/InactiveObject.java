package pt.iscte.dcti.poo.sokoban.starter;

public interface InactiveObject {

}
